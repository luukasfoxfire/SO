# Battleship

Programa en C de la primera tarea del ramo de Sistemas Operativos, el cual consiste en la realización de un juego de estilo Battleship.

## Instrucciones de compilación
Utilizando el makefile los comandos son los siguientes:
    make            -Para compilar el programa.
    make run        -Para compilar el programa y ejecutarlo.
    make clean      -Para limpiar los archivos temporales creados por el programa, incluyendo el archivo ya compilado.

Si ya se encuentra compilado solo se requiere del comando ./Battleship


## Notas

Este programa fue compilado y probado utilizando la versión C11 de C Standard.

## Autor

* Lukas Cisterna
